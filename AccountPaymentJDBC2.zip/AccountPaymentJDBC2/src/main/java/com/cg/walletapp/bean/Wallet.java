package com.cg.walletapp.bean;

import java.math.BigDecimal;

public class Wallet {

	private BigDecimal balance=new BigDecimal("0");

	
	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	@Override
		public String toString() {
		return " balance="+balance;
	}
}