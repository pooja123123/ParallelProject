package com.cg.walletapp.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;

import com.cg.util.JavaUtil;
import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.exception.IWalletException;
import com.cg.walletapp.exception.WalletException;

public class WalletDaoImpl implements IWalletDao {
	Connection con = null;

	public WalletDaoImpl() {

		con = JavaUtil.getConnect();
	}

	public void addAccountDao(Customer customer) throws WalletException {
		String sql = "INSERT INTO WALLETAPP VALUES(?, ?, ?)";

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setString(1, customer.getName());
			pstmt.setString(2, customer.getMobileNo());
			pstmt.setBigDecimal(3, customer.getWalletBalance());
			pstmt.executeUpdate();
		} catch (SQLException e) {

			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}
	}

	public Customer findOne(String mobnum) throws WalletException {

		Customer customersearch = new Customer();
		String sql = "SELECT * FROM WALLETAPP WHERE MOBILE = ?";

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobnum);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				customersearch.setName(res.getString(1));
				customersearch.setWalletBalance(res.getBigDecimal(3));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);

		}
		return customersearch;
	}

	public void addTransactions(String mobnum, String str) throws WalletException {

		try {
			String sql = "INSERT INTO TRANSACTIONS VALUES(?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobnum);
			pstmt.setString(2, str);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}

	}

	public List<String> printTransactionsDao(String mobnum) throws WalletException {

		List<String> transaction = new ArrayList<String>();
		String sql = "SELECT * FROM TRANSACTIONS WHERE MOBILE=?";

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobnum);
			ResultSet res = pstmt.executeQuery();

			if (res.next()) {
				while (res.next()) {
					transaction.add(res.getString(2));

				}

			} 
		} catch (SQLException e) {

			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}
		return transaction;
	}

	public boolean checkMobno(String mobnum) throws WalletException {
		boolean flag = false;

		String sql = "SELECT * FROM WALLETAPP WHERE MOBILE= ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobnum);
			ResultSet res = pstmt.executeQuery();
			if (res.next())
				flag = true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}
		return flag;

	}

	public void updateBalance(String mobnum, BigDecimal amount) throws WalletException {

		String sql = "UPDATE WALLETAPP SET BALANCE= ? WHERE MOBILE= ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setBigDecimal(1, amount);
			pstmt.setString(2, mobnum);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new WalletException(IWalletException.ERROR3);
		}
	}
}