package com.cg.walletapp.dao;

import java.math.BigDecimal;
import java.util.List;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.exception.WalletException;

public interface IWalletDao {

	public void addAccountDao(Customer customer) throws WalletException;

	public Customer findOne(String mobnum) throws WalletException;
	
	public void addTransactions(String mobnum, String string) throws WalletException;
	public List<String> printTransactionsDao(String mobnum) throws WalletException;
	public boolean checkMobno(String mobnum) throws WalletException;
	public void updateBalance(String mobnum, BigDecimal amount) throws WalletException;
}
